About
============
Sometimes customer comments on the product are very important for improving product quality, service, his satisfy their needs, and eventually to keep them loyal to your brand on the product. You will provide this feature using the 'Customer Note in Website Cart/Order' module. you can manage customer comments on each order, order report, invoice, invoice report, delivery, delivery report, so you can easily interact with the customer.


Installation
============
1) Copy module files to addon folder.
2) Restart odoo service (sudo service odoo-server restart).
3) Go to your odoo instance and open apps (make sure to activate debug mode).
4) click on update app list. 
5) search module name and hit install button.

Softhealer Technologies Support Team
=====================================
Skype: live:softhealertechnologies
What's app: +917984575681
E-Mail: suppport@softhealer.com
Website: https://softhealer.com
