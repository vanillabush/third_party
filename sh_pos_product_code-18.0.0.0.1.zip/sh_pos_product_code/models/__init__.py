# Part of Softhealer Technologies.

from . import pos_config, res_cofig_settings
